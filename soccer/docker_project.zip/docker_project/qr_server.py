"""
qr_server.py
────────────
Tiny aiohttp server that serves the QR-code screenshot so you can
open http://VPS_IP:8080 in any browser and scan the QR with your phone.
Page auto-refreshes every 3 seconds.
"""

from __future__ import annotations

import base64
import logging
import time
from pathlib import Path

from aiohttp import web

from exceptions import QRServerError

log = logging.getLogger(__name__)

QR_IMAGE_PATH = Path("/tmp/qr_current.png")

# ── HTML page ─────────────────────────────────────────────────────────────────
_PAGE = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ShamCash – Scan QR</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      display: flex; flex-direction: column;
      align-items: center; justify-content: center;
      min-height: 100vh; background: #0d0d0d; color: #eee;
      font-family: system-ui, sans-serif; gap: 1.2rem; padding: 2rem;
    }}
    h1   {{ font-size: 1.4rem; text-align: center; }}
    img  {{ max-width: 380px; width: 90vw; border-radius: 16px;
            box-shadow: 0 0 40px #00ff8855; background: #fff; padding: 12px; }}
    .badge {{
      display: inline-block; padding: .35em 1em;
      background: {color}; border-radius: 999px;
      color: #111; font-weight: 700; font-size: .95rem;
    }}
    small {{ color: #555; font-size: .8rem; }}
  </style>
  <meta http-equiv="refresh" content="3">
</head>
<body>
  <h1>📱 Open ShamCash on your Android &amp; scan</h1>
  <img src="/qr.png?t={ts}" alt="QR code">
  <span class="badge">{status}</span>
  <small>Page refreshes automatically every 3 s</small>
</body>
</html>
"""

# BUG FIX: previous version used bytes.fromhex() across a multi-line string
# where .replace(" ","") only applied to the LAST line — leaving spaces in the
# middle that caused ValueError: non-hexadecimal number found at position 135.
# Fix: use base64.b64decode() which has no such string-concatenation trap.
# This decodes to a valid 1×1 transparent PNG.
_BLANK_PNG: bytes = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwC"
    "AAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


class QRServer:
    """
    Async context manager that runs a lightweight HTTP server.

    Usage
    ─────
    async with QRServer(port=8080) as srv:
        await srv.update(png_bytes)
        srv.set_status("Waiting…", "#ffdd00")
    """

    def __init__(self, port: int = 8080) -> None:
        self._port   = port
        self._status = "Starting…"
        self._color  = "#888888"
        self._runner: web.AppRunner | None = None

    async def __aenter__(self) -> "QRServer":
        try:
            app = web.Application()
            app.router.add_get("/",       self._handle_index)
            app.router.add_get("/qr.png", self._handle_image)
            self._runner = web.AppRunner(app)
            await self._runner.setup()
            site = web.TCPSite(self._runner, "0.0.0.0", self._port)
            await site.start()
            log.info("QR server listening on port %s", self._port)
        except Exception as exc:
            raise QRServerError(
                f"Could not start QR server on port {self._port}: {exc}"
            ) from exc
        return self

    async def __aexit__(self, *_) -> None:
        if self._runner:
            await self._runner.cleanup()
            log.info("QR server stopped")

    async def _handle_index(self, _request: web.Request) -> web.Response:
        html = _PAGE.format(ts=int(time.time()), status=self._status, color=self._color)
        return web.Response(text=html, content_type="text/html")

    async def _handle_image(self, _request: web.Request) -> web.Response:
        if QR_IMAGE_PATH.exists():
            return web.Response(body=QR_IMAGE_PATH.read_bytes(), content_type="image/png")
        return web.Response(body=_BLANK_PNG, content_type="image/png")

    async def update(self, screenshot_bytes: bytes) -> None:
        QR_IMAGE_PATH.write_bytes(screenshot_bytes)

    def set_status(self, message: str, color: str = "#ffdd00") -> None:
        """  "#ffdd00" waiting  |  "#00ff88" success  |  "#ff4444" error  """
        self._status = message
        self._color  = color
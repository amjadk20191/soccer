#!/usr/bin/env python3
"""
main.py  —  shamcash.sy transaction scraper  (Docker / Linux VPS)

BUG FIX (bug 5): previous version used old bool API:
    if not await session.ensure_logged_in(...): return
    if not await session.relogin_if_needed(...): break
Now catches proper exceptions so session expiry triggers re-login instead
of silently stopping.
"""

import asyncio
import logging
import os
from datetime import datetime

from dotenv import load_dotenv
load_dotenv()

from config import load_config
from db import create_repository           # BUG FIX (bug 1): db/__init__.py now exports this
from exceptions import (
    AuthenticationError,
    DatabaseError,
    LoginTimeoutError,
    ParseError,
    QRServerError,
    ScrapingError,
    SessionExpiredError,
)
from models import Transaction
from scraper import BrowserSession, fetch_transactions

logging.basicConfig(
    level  = logging.INFO,
    format = "%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
    datefmt= "%H:%M:%S",
)
log = logging.getLogger(__name__)

_MAX_SCRAPE_FAILURES = 5


def _fmt(tx: Transaction) -> str:
    label = "IN " if tx.direction == "+" else "OUT"
    return (
        f"  [{label}]  "
        f"id:{tx.tx_id:<12}  "
        f"name:{tx.name:<30}  "
        f"amount:{str(tx.amount):<10} {tx.currency:<4}  "
        f"date:{tx.date}  time:{tx.time}"
    )


def _print_batch(transactions: list[Transaction], new_count: int) -> None:
    now = datetime.now().strftime("%H:%M:%S")
    print(f"\n{'═' * 80}")
    print(f"  {len(transactions)} transaction(s)  │  {new_count} new  │  {now}")
    print(f"{'═' * 80}")
    for tx in transactions:
        print(_fmt(tx))
    print(f"{'═' * 80}\n")


async def main() -> None:
    cfg       = load_config()
    qr_port   = int(os.getenv("QR_PORT", "8080"))
    login_url = f"{cfg.base_url}/ar/auth/login"
    tx_url    = f"{cfg.base_url}/ar/application/transaction"

    # ── QR server + browser ───────────────────────────────────────────────────
    try:
        async with BrowserSession(cfg.session_file, cfg.base_url, qr_port) as session:
            await _run(session, cfg, login_url, tx_url)

    except QRServerError as exc:
        # Port already in use — nothing else to do
        log.critical("QR server failed: %s", exc)
        print(f"\n[✗] Cannot start QR server on port {qr_port}.")
        print("    Change QR_PORT in your .env and restart.\n")


async def _run(session: "BrowserSession", cfg, login_url: str, tx_url: str) -> None:

    # ── initial login ─────────────────────────────────────────────────────────
    try:
        await session.ensure_logged_in(login_url)
    except AuthenticationError as exc:
        log.critical("Cannot reach login page: %s", exc)
        print(f"\n[✗] {exc}\n    Check BASE_URL and VPS network.\n")
        return
    except LoginTimeoutError:
        print("\n[✗] QR scan timed out. Restart and try again.\n")
        return

    # ── database ──────────────────────────────────────────────────────────────
    try:
        repo = create_repository(cfg.database_url, cfg.db_table)
    except DatabaseError as exc:
        log.critical("DB init failed: %s", exc)
        print(f"\n[✗] Database error: {exc}\n")
        return

    with repo:
        print(f"[→] Polling every {cfg.poll_interval}s  (Ctrl+C to stop)\n")
        scrape_failures = 0

        while True:
            try:
                # ── fetch ─────────────────────────────────────────────────────
                transactions = await fetch_transactions(session.page, tx_url)
                scrape_failures = 0

                # ── session-expiry check ──────────────────────────────────────
                # BUG FIX (bug 5): was `if not relogin_if_needed(): break`
                # Now relogin_if_needed() raises SessionExpiredError instead.
                await session.relogin_if_needed(login_url)

                # ── save ──────────────────────────────────────────────────────
                try:
                    new_count = repo.save_many(transactions)
                    _print_batch(transactions, new_count)
                except DatabaseError as exc:
                    log.error("DB write failed (retry next cycle): %s", exc)
                    print(f"[!] DB error: {exc}")

            except SessionExpiredError:
                # Re-login flow — shows QR again, waits for scan, then resumes
                try:
                    await session.handle_relogin(login_url)
                    scrape_failures = 0
                except LoginTimeoutError:
                    print("[!] Re-login timed out — will retry next cycle.")
                except AuthenticationError as exc:
                    log.error("Re-login failed: %s", exc)
                    print(f"[!] {exc}  — retrying in 30 s")
                    await asyncio.sleep(30)

            except ScrapingError as exc:
                scrape_failures += 1
                print(f"[!] Scrape failed ({scrape_failures}/{_MAX_SCRAPE_FAILURES}): {exc}")
                if scrape_failures >= _MAX_SCRAPE_FAILURES:
                    log.critical("Too many consecutive scrape failures — stopping")
                    print(f"\n[✗] Scraping failed {_MAX_SCRAPE_FAILURES} times in a row.\n"
                          "    Page structure may have changed.\n")
                    return

            except ParseError as exc:
                log.warning("Parse error (row skipped): %s", exc)
                print(f"[~] Parse warning: {exc}")

            except KeyboardInterrupt:
                print("\n[→] Stopped by user.")
                return

            except Exception as exc:
                log.exception("Unexpected error: %s", exc)
                print(f"[!] Unexpected error: {exc!r}  — retrying in 10 s")
                await asyncio.sleep(10)
                continue

            await asyncio.sleep(cfg.poll_interval)


if __name__ == "__main__":
    asyncio.run(main())
"""
scraper/browser.py
──────────────────
Headless Chromium session for Linux / Docker.

BUG FIX (bug 6): previous version never imported or raised any custom
exceptions — auth errors were swallowed silently and re-login never triggered.
Now raises proper exceptions that main.py catches and acts on.

Raises
──────
AuthenticationError  – base URL unreachable
LoginTimeoutError    – QR not scanned within 5 minutes
SessionExpiredError  – page redirected back to /auth/login mid-poll
QRServerError        – HTTP server failed to start (propagated from qr_server)
"""

from __future__ import annotations

import asyncio
import logging
import os

from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Page,
    Playwright,
)

from exceptions import (
    AuthenticationError,
    LoginTimeoutError,
    SessionExpiredError,
)
from qr_server import QRServer   # QRServerError propagates up from here

log = logging.getLogger(__name__)


class BrowserSession:

    def __init__(self, session_file: str, base_url: str, qr_port: int = 8080) -> None:
        self._session_file = session_file
        self._base_url     = base_url
        self._qr_port      = qr_port
        self._playwright: Playwright | None     = None
        self._browser:    Browser | None        = None
        self._context:    BrowserContext | None = None
        self._page:       Page | None           = None
        self._qr_server:  QRServer | None       = None

    # ── context manager ───────────────────────────────────────────────────────

    async def __aenter__(self) -> "BrowserSession":
        self._playwright = await async_playwright().start()
        self._browser    = await self._playwright.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
            ],
        )
        # QRServerError raised here if port is busy — propagates to main.py
        self._qr_server = QRServer(self._qr_port)
        await self._qr_server.__aenter__()
        await self._new_context()
        return self

    async def __aexit__(self, *_) -> None:
        if self._browser:    await self._browser.close()
        if self._playwright: await self._playwright.stop()
        if self._qr_server:  await self._qr_server.__aexit__()

    async def _new_context(self) -> None:
        if self._context:
            await self._context.close()
        kwargs: dict = {}
        if os.path.exists(self._session_file):
            kwargs["storage_state"] = self._session_file
        self._context = await self._browser.new_context(**kwargs)
        self._page    = await self._context.new_page()

    @property
    def page(self) -> Page:
        if self._page is None:
            raise RuntimeError("BrowserSession not entered — use `async with`")
        return self._page

    # ── public API ────────────────────────────────────────────────────────────

    async def ensure_logged_in(self, login_url: str) -> None:
        """
        BUG FIX (bug 5+6): was `return bool` — now raises on failure so
        main.py gets a real signal instead of a silent False.

        Raises: AuthenticationError, LoginTimeoutError, QRServerError
        """
        try:
            await self._page.goto(self._base_url, wait_until="networkidle")
            await self._page.wait_for_timeout(1_500)
        except Exception as exc:
            raise AuthenticationError(
                f"Could not reach {self._base_url}: {exc}"
            ) from exc

        if "/auth/login" not in self._page.url:
            log.info("Session restored — no QR scan needed")
            print("[✓] Session restored — no QR scan needed\n")
            return   # ← already authenticated, nothing to do

        await self._do_qr_login(login_url)

    async def relogin_if_needed(self, login_url: str) -> None:
        """
        BUG FIX (bug 5+6): was `return bool` — now raises SessionExpiredError
        so main.py can catch it and call handle_relogin() explicitly.

        Raises: SessionExpiredError
        """
        if "/auth/login" not in self._page.url:
            return   # still authenticated

        log.warning("Session expired mid-run")
        print("\n[!] Session expired — please scan the QR code again.\n")
        raise SessionExpiredError("Browser was redirected to /auth/login during polling")

    async def handle_relogin(self, login_url: str) -> None:
        """
        Called by main.py after catching SessionExpiredError.
        Raises: LoginTimeoutError, AuthenticationError
        """
        await self._new_context()
        await self._do_qr_login(login_url)

    # ── internal ──────────────────────────────────────────────────────────────

    async def _do_qr_login(self, login_url: str) -> None:
        """
        Raises: LoginTimeoutError
        """
        await self._page.goto(login_url, wait_until="networkidle")
        await self._page.wait_for_timeout(2_000)

        self._qr_server.set_status("Waiting for QR scan…", "#ffdd00")
        print("\n" + "=" * 60)
        print(f"  Open  http://YOUR_VPS_IP:{self._qr_port}  in your browser")
        print("  Then scan the QR with your Android ShamCash app")
        print("=" * 60 + "\n")

        async def _screenshot_loop() -> None:
            while True:
                try:
                    qr_el = await self._page.query_selector(
                        "canvas, img[src*='qr'], img[alt*='qr' i], [class*='qr' i]"
                    )
                    png = await (qr_el.screenshot() if qr_el
                                 else self._page.screenshot(full_page=False))
                    await self._qr_server.update(png)
                except Exception:
                    pass
                await asyncio.sleep(3)

        screenshot_task = asyncio.create_task(_screenshot_loop())
        try:
            await self._page.wait_for_url(
                lambda url: "/auth/login" not in url,
                timeout=300_000,
            )
        except Exception as exc:
            screenshot_task.cancel()
            self._qr_server.set_status("Timeout — restart container", "#ff4444")
            raise LoginTimeoutError("QR code was not scanned within 5 minutes") from exc

        screenshot_task.cancel()
        log.info("QR scan successful — saving session")
        print("[✓] Logged in!\n")
        self._qr_server.set_status("Logged in ✓ — scraping…", "#00ff88")
        await self._save_session()

    async def _save_session(self) -> None:
        os.makedirs(os.path.dirname(self._session_file) or ".", exist_ok=True)
        await self._context.storage_state(path=self._session_file)
        log.info("Session saved → %s", self._session_file)
        print(f"[✓] Session saved → {self._session_file}")
"""
scraper/fetcher.py
──────────────────
Three fetch strategies tried in order:
  1. JSON API intercept  (fastest — captures XHR before the DOM is built)
  2. Desktop <table>     (HTML fallback)
  3. Mobile card layout  (narrow-viewport fallback)

FIX: strategies 2 and 3 now navigate to the page themselves if they are called
directly (e.g. strategy 1 errored mid-navigation).  Each strategy is fully
self-contained.
"""

from playwright.async_api import Page

from scraper.parser import build_transaction
from models import Transaction


# ── strategy 1 : JSON API intercept ──────────────────────────────────────────

async def _fetch_via_api(page: Page, transactions_url: str) -> list[dict]:
    """
    Attach a response listener BEFORE navigating so we capture the XHR
    the SPA fires to populate the transactions list.
    """
    api_items: list[dict] = []

    async def on_response(response):
        if "transaction" not in response.url or response.status != 200:
            return
        try:
            data = await response.json()
        except Exception:
            return

        items = data if isinstance(data, list) else None
        if not items and isinstance(data, dict):
            for key in ("results", "data", "transactions", "items"):
                if key in data and isinstance(data[key], list):
                    items = data[key]
                    break
        if items:
            api_items.extend(items)

    page.on("response", on_response)
    try:
        await page.goto(transactions_url, wait_until="networkidle")
        await page.wait_for_timeout(2_500)
    finally:
        page.remove_listener("response", on_response)

    if not api_items:
        return []

    raw_list = []
    for tx in api_items:
        raw_amount = str(tx.get("amount") or tx.get("value") or "")
        sign_field = str(tx.get("type") or tx.get("direction") or "")

        if raw_amount and raw_amount[0] not in ("+", "-"):
            if any(k in sign_field.lower() for k in ("in", "receive", "credit")):
                raw_amount = "+" + raw_amount
            elif any(k in sign_field.lower() for k in ("out", "send", "debit")):
                raw_amount = "-" + raw_amount

        currency   = tx.get("currency", "SYP")
        amount_raw = f"{raw_amount} {currency}".strip()

        raw_list.append({
            "id":         str(tx.get("id") or tx.get("ref") or ""),
            "name":       (tx.get("from") or tx.get("sender")
                           or tx.get("from_user") or "N/A"),
            "date_raw":   (tx.get("date") or tx.get("created_at")
                           or tx.get("timestamp") or ""),
            "amount_raw": amount_raw,
            "notes":      tx.get("note") or tx.get("description") or "",
        })

    return raw_list


# ── strategy 2 : desktop <table> ─────────────────────────────────────────────

async def _fetch_via_table(page: Page, transactions_url: str) -> list[dict]:
    """
    FIX: now navigates to transactions_url itself so it is self-contained.
    Columns: 0=name+card  1=#ID  2=date  3=amount  4=notes
    """
    # Navigate only if we are not already on the transactions page.
    # (Strategy 1 may have already done so successfully.)
    if transactions_url not in page.url:
        await page.goto(transactions_url, wait_until="networkidle")
        await page.wait_for_timeout(1_500)

    raw_list = []
    rows = await page.query_selector_all("table tbody tr")

    for row in rows:
        cells = await row.query_selector_all("td")
        if len(cells) < 4:
            continue

        name_el = await cells[0].query_selector("span.font-semibold")
        if name_el:
            name = (await name_el.inner_text()).strip()
        else:
            lines = (await cells[0].inner_text()).strip().splitlines()
            name  = next((ln.strip() for ln in lines if ln.strip()), "")

        raw_id     = (await cells[1].inner_text()).strip().lstrip("#")
        date_raw   = (await cells[2].inner_text()).strip()
        amount_raw = (await cells[3].inner_text()).strip()
        notes      = (await cells[4].inner_text()).strip() if len(cells) >= 5 else ""

        if raw_id:
            raw_list.append({
                "id": raw_id, "name": name,
                "date_raw": date_raw, "amount_raw": amount_raw, "notes": notes,
            })

    return raw_list


# ── strategy 3 : mobile card layout ──────────────────────────────────────────

async def _fetch_via_mobile_cards(page: Page, transactions_url: str) -> list[dict]:
    """
    FIX: now navigates to transactions_url itself so it is self-contained.
    Fallback for narrow viewports where the table is hidden (block md:hidden).
    """
    if transactions_url not in page.url:
        await page.goto(transactions_url, wait_until="networkidle")
        await page.wait_for_timeout(1_500)

    raw_list = []
    cards = await page.query_selector_all(".block.md\\:hidden .flex.flex-col")

    for card in cards:
        spans = await card.query_selector_all("span")
        texts = [(await s.inner_text()).strip() for s in spans]

        tx_id = amount_raw = date_raw = name = ""
        for t in texts:
            if t.startswith("#") and t[1:].split()[0].isdigit():
                tx_id = t.lstrip("#")
            elif t and t[0] in ("+", "-") and any(c.isdigit() for c in t):
                amount_raw = t
            elif " - " in t and len(t) > 15:
                date_raw = t
            elif t and not name:
                name = t

        if tx_id:
            raw_list.append({
                "id": tx_id, "name": name,
                "date_raw": date_raw, "amount_raw": amount_raw, "notes": "",
            })

    return raw_list


# ── public entry point ────────────────────────────────────────────────────────

async def fetch_transactions(page: Page, transactions_url: str) -> list[Transaction]:
    """
    Try three strategies in order.  Each is fully self-contained and navigates
    to transactions_url on its own if the page is not already there.
    Returns a list of typed Transactions (empty list if all strategies fail).
    """
    for strategy in (
        lambda: _fetch_via_api(page, transactions_url),
        lambda: _fetch_via_table(page, transactions_url),
        lambda: _fetch_via_mobile_cards(page, transactions_url),
    ):
        raw_list = await strategy()
        if raw_list:
            transactions = [build_transaction(r) for r in raw_list]
            return [tx for tx in transactions if tx is not None]

    return []